    <!-- Seção Home -->
    <section id="home" class="hero section dark-background">

      <h1>ESTOQUE</h1>
    

    </section><!-- /Seção Home -->