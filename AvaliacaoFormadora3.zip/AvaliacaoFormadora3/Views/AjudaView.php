    <!-- Seção Home -->
    <section id="home" class="hero section dark-background">

      <h1>AJUDA</h1>
    

    </section><!-- /Seção Home -->