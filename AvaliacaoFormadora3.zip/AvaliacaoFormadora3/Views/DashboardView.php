    <!-- Seção Home -->
    <section id="home" class="hero section dark-background">

      <img src="<?php echo BASE_URL ?>/assets/img/foto-home.jpg" alt="" data-aos="fade-in" class="">

      <div class="container" data-aos="fade-up" data-aos-delay="100">


      </div>
      

    </section><!-- /Seção Home -->
