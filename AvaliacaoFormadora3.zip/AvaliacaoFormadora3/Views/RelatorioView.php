    <!-- Seção Home -->
    <section id="home" class="hero section dark-background">

      <h1>RELATORIOS</h1>
    

    </section><!-- /Seção Home -->