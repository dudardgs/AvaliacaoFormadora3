    <!-- Seção Erro -->
    <section id="erro" class="hero section dark-background">

      <img src="<?php echo BASE_URL ?>/assets/img/erro.png" alt="" data-aos="fade-in" class="">

    </section><!-- /Seção Erro -->
