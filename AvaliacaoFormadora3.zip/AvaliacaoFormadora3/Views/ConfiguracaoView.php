    <!-- Seção Home -->
    <section id="home" class="hero section dark-background">

      <h1>CONFIGURAÇÕES</h1>
    

    </section><!-- /Seção Home -->