<?php
// Autoload para carregar automaticamente as classes
require 'autoload.php';
$app = new App();

?>