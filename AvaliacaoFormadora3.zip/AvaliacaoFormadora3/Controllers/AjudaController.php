<?php
class AjudaController extends Controller{

    public function index(){
        $this->carregarEstrutura('AjudaView');
    }


}



?>