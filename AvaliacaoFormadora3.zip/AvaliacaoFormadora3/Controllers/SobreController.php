<?php
class SobreController extends Controller{

    public function index(){
        $this->carregarEstrutura('SobreView');
    }


}



?>