<?php
class ConfiguracaoController extends Controller{

    public function index(){
        $this->carregarEstrutura('ConfiguracaoView');
    }


}



?>