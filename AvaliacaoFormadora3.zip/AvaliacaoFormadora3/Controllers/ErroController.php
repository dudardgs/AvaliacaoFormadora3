<?php
class ErroController extends Controller{

    public function index(){
        $this->carregarEstrutura("ErroView");
    }



}


?>