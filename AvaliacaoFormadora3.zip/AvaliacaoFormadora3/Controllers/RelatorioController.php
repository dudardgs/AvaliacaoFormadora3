<?php
class RelatorioController extends Controller{

    public function index(){
        $this->carregarEstrutura('RelatorioView');
    }


}



?>