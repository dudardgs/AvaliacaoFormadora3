<?php
class EstoqueController extends Controller{

    public function index(){
        $this->carregarEstrutura('EstoqueView');
    }

}





?>