<?php
require_once __DIR__ . '/../Models/Livro.php';
require_once __DIR__ . '/../Models/ClienteFisico.php';
require_once __DIR__ . '/../Models/Venda.php';
require_once __DIR__ . '/../Models/ItemVendaLivro.php';

$livro = new Livro('L1','978-0000','UML Fácil',2025,5,59.90);
$cliente = new ClienteFisico();
$cliente->setIdCliente(1);
$cliente->setEndereco('Rua A, 123');
$cliente->setCredito(500);
$cliente->setTipoCliente('FISICO');
$cliente->setNome('Maria');
$cliente->setCpf('123.456.789-00');

$venda = new Venda();
$venda->setIdVenda(10);
$venda->setFormaPagto('Pix');
$venda->setCliente($cliente);

$item = new ItemVendaLivro();
$item->setLivro($livro);
$item->setVenda($venda);
$item->setQteVendida(2);

header('Content-Type: application/json; charset=utf-8');
echo json_encode([
  'livro'   => $livro->toArray(),
  'cliente' => $cliente->toArray(),
  'venda'   => $venda->toArray(),
  'item'    => $item->toArray(),
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);